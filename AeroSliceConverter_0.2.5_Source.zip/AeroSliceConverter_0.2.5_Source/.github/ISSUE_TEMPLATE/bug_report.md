---
name: Bug report / 问题反馈
about: Reproducible conversion or slicing issue / 转换或切片问题
title: "[Bug] "
labels: bug
---

**Version / 软件版本：**
**Windows version / 系统版本：**
**Original or already converted? / 原始还是已转换模型：**
**Input type and role / STL或3MF、结构类型：**
**Reconstruction mode, height, material width / 重建方式、层高、材料宽度：**
**Slicer and version / 切片器及版本：**
**Even-Odd, wall generator, walls and infill / 奇偶、墙生成器、墙数、填充：**
**Slicing height AND first-layer height / 切片层高和首层高度：**
**Z / scale / orientation changes / Z位置、缩放、旋转：**

### Steps and expected / actual behavior / 复现、预期和实际结果

### First error or logs / 首条报错或日志
Remove personal paths / 请移除个人路径。

### Screenshot with layer number / 带层号的实际刀路截图

### Minimal example you are permitted to share / 有权公开的最小复现
Do not upload purchased or restricted aircraft models without permission.
请勿未经授权公开付费或受限航模。
