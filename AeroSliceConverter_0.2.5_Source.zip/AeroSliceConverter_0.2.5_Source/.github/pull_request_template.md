## Problem and resulting behavior / 问题与修改后行为

## Validation and limits / 验证方式与限制
- [ ] Tests run; commands and results below / 已运行测试，附命令与结果
- [ ] UI screenshot or slicing comparison when relevant / 涉及时附界面或刀路对照
- [ ] Source model unchanged; no private or restricted model data / 源模型不变，未附受限数据
- [ ] Default layered workflow and model-only export preserved / 保留默认逐层及仅模型导出

## Third-party code or dependencies / 第三方代码及依赖
Identify origin and license; leave empty if none / 如有请注明来源与许可。
