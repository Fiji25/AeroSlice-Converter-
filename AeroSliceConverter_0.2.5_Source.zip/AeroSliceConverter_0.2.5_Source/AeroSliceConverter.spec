from PyInstaller.utils.hooks import collect_all, collect_submodules,collect_delvewheel_libs_directory,collect_dynamic_libs

datas=[]
binaries=[]
hiddenimports=[]
for package in ('pyqtgraph','OpenGL','manifold3d','rtree','trimesh','shapely'):
    d,b,h=collect_all(package)
    datas+=d;binaries+=b;hiddenimports+=h
datas += [('docs','docs'),('README.md','.'),('requirements.txt','.'),('THIRD_PARTY_NOTICES.md','.')]
hiddenimports += ['PySide6.QtOpenGL','PySide6.QtOpenGLWidgets','scipy.sparse.csgraph','scipy.spatial._ckdtree']
hiddenimports += collect_submodules('numpy.f2py')
hiddenimports += ['meshlib.mrmeshpy','meshlib.mrmeshnumpy']
hiddenimports += ['networkx']
datas,binaries=collect_delvewheel_libs_directory('meshlib',libdir_name='meshlib_core.libs',datas=datas,binaries=binaries)
binaries+=collect_dynamic_libs('meshlib')
a=Analysis(['main.py'],pathex=['src'],binaries=binaries,datas=datas,hiddenimports=hiddenimports,
           excludes=['PyQt5','PyQt6','PySide2','tkinter','matplotlib','pandas','IPython','jupyter','pytest'])
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='AeroSliceConverter',console=False,
        debug=False,strip=False,upx=False)
cli=EXE(pyz,a.scripts,[],exclude_binaries=True,name='AeroSliceCLI',console=True,
        debug=False,strip=False,upx=False)
coll=COLLECT(exe,cli,a.binaries,a.datas,strip=False,upx=False,name='AeroSliceConverter_0.2.5')
