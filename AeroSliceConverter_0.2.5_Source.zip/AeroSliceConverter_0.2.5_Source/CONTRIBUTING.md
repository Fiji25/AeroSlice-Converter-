# Contributing / 参与改进

Thank you for helping make aircraft model conversion easier. Read the README's current limits and third-party notices first. The project's formal license and commercial-authorization arrangement are pending; discussing a PR does not establish an exclusive commercial license. Keep copyright notices and identify third-party code and its license. Do not add code or model files you cannot share.

## Report a reproducible problem

Use the bug template. Include application version, original/converted status, reconstruction mode, height, material width, role selection, slicer version/mode, slicing and first-layer heights, Z changes and the report's first error. Toolpath screenshots should show layer number and what is missing. Share a minimal reproduction only when you have permission; a filename and logs are preferable to uploading a purchased aircraft model. Remove personal paths and payment data from reports.

## Submit a focused change

Use a branch, explain the behavior before/after, and add a regression test for a meaningful bug. Run `python -m pytest -q --basetemp .tmp/pytest-local` after creating `.tmp`. Keep source models unchanged, use temporary outputs, and do not commit runtimes or model data. Keep layered reconstruction the default. Preserve conversion-cache invalidation and the desktop rule of model-only export. Changes to geometry require before/after slice evidence; do not infer printer success from a watertight mesh alone.

The Windows CI runs Python 3.12 source tests. Builds and real slicer/printing validation are separate. Include a screenshot for UI changes and state what has and has not been checked.

## 中文

欢迎通过 Issue、讨论和小范围 PR 改进项目。正式许可与贡献者商业授权安排仍待确定；提交讨论不等于授予作者独占商业授权。保留版权与第三方许可说明，不提交无权公开的代码或航模。

报告问题请注明软件版本、是否原始模型、重建方式、层高、材料宽度、结构类型、切片器版本、奇偶模式、切片层高、首层高度、Z 变化与首条报错。缺线截图应显示层号和位置。付费或受限航模不要直接公开上传，可提供有权分享的最小复现。移除日志里的个人路径等信息。

提交修复应说明修改前后行为和验证范围。推荐 Python 3.12；先创建 `.tmp`，运行上述测试命令。保持原始模型不变，不提交 EXE、运行库或模型数据。默认逐层方案、缓存失效规则和桌面仅导出模型的行为须保留。几何修改需要逐层对照证据，不能把封闭网格当作打印通过。

赞助分配由作者与贡献者结合质量、影响和维护投入沟通确定，不承诺固定金额、比例或时间。
