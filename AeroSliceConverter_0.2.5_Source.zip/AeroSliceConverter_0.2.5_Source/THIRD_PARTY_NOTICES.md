# Third-party dependencies / 第三方依赖

This source archive contains application code and tests. It does not bundle third-party runtime libraries, DLLs, Python wheels, or aircraft STL/3MF data.
本源码包包含应用代码和测试，不捆绑第三方运行库、DLL、Python安装包或航模STL/3MF数据。

Install dependencies under their own applicable licenses. Dependency names and pinned versions are recorded in requirements.txt and requirements-lock.txt. Keep applicable notices when creating a binary distribution.
安装和使用依赖须遵守其各自的许可证。名称及版本见依赖清单；制作二进制分发包时须保留适用声明并核对再分发条件。

In particular, the installed meshlib-core 3.1.4.297 package carries a NON-COMMERCIAL & education LICENSE AGREEMENT, including restrictions on transfer to third parties. No permission to redistribute that runtime is granted by this source archive.
其中，当前使用的meshlib-core 3.1.4.297随包许可证为NON-COMMERCIAL & education LICENSE AGREEMENT，含第三方转移限制。本源码包不授予该运行库的再分发许可。

https://meshlib.io/license/

No project-wide open-source or no-resale license is added by this packaging operation. The owner's intended project license must be finalized separately. Making a repository public does not itself turn it into OSI-defined open source.
本次整理未新增项目统一开源许可或禁止售卖许可；项目权利人的许可选择仍须另行确定。公开仓库本身不等同于OSI定义的开源。
