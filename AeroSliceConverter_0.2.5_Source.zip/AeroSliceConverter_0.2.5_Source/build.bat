@echo off
setlocal
cd /d "%~dp0"
if not exist .tmp mkdir .tmp
set "TEMP=%CD%\.tmp"
set "TMP=%TEMP%"
if not exist .venv\Scripts\python.exe (
  py -3.12 -m venv .venv
  if errorlevel 1 py -3.11 -m venv .venv
)
if not exist .venv\Scripts\python.exe exit /b 1
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m pytest -q --basetemp .tmp\pytest-build
if errorlevel 1 exit /b 1
.venv\Scripts\python.exe -m PyInstaller --noconfirm --distpath dist_verified AeroSliceConverter.spec
if errorlevel 1 exit /b 1
echo Output: %CD%\dist_verified\AeroSliceConverter_0.2.5\AeroSliceConverter.exe
endlocal
