# 0.2.5 连续薄壁验证报告

验证对象：原始 **Fuselage 3-p3.stl**。版本仍为 **0.2.5**，替换上一份同版本本地测试包。默认保持逐层；本次连续薄壁需手动选择，使用 Regular 普通实体切片。

## 结论

连续薄壁的几何检查、不同层高的完整 G-code 生成及最终 EXE 导入/转换/复用导出通过。**局部刀路间隙仍存在，工程 3MF 保存失败，未验证实物打印，不能宣称全流程毫无问题或所有模型通用。**

原始曲面直接进行双侧薄壁重建，不通过 G-code 逆向，不平滑逐层堆叠 STL。厚度 0.45 mm，几何重建精度 0.10 mm；打印层高与首层高度由切片软件设置。

## 几何检查

- 成品 1,039,870 面，约 52 MB；此前逐层成品为 2,003,904 面，面数减少约 48.1%。连续成品不按 0.2 mm 封闭薄层叠加，近水平三角面仅 852 个（不能把这一数字理解为完整外观认证）。
- 118,049 个源顶点与面心覆盖通过；一个伪法线内外判定误报经绕数与独立射线联合确认后纠正。真实遗漏仍拒绝导出，原容差不变。
- 输出为闭合有效体；全部三角面原生自相交检查通过。342 个远离源面的空腔探针未发现意外填实。
- 20,000 个输出表面采样点到源面的最大距离约 0.2843 mm，平均 0.2269 mm，包含名义约 0.225 mm 的双侧外扩。不是无损尺寸转换，不是全局 Hausdorff 证明，接口须另核对。
- 原文件 SHA-256：`80e8404ff2551002b916f5c20a7a8d8d7157c8d7c4f66141b0a19688736b83e3`，验证前后不变。
- 连续成品 SHA-256：`378f03fd5361e49a2c38fe88063ffbd05671a21506f624a19e2ff65fb678f820`。

## 拓竹实际刀路验证

参考机型 P1S、0.4 mm 喷嘴、Regular、Arachne、3 墙、100% 材料区域填充、顶底 0 层。两次使用完全相同的 STL，只修改层高与首层高度；验证用副本平移到打印板，成品坐标未修改。

| 层高 / 首层 | G-code 模型层数 | 有原始截线的核对层数 | 整层缺失 | 截线刀路覆盖抽样 | 最差单层覆盖 |
|---|---:|---:|---:|---:|---:|
| 0.20 / 0.24 mm | 742 | 740 | 0 | 99.9917% | 99.7919% |
| 0.16 / 0.20 mm | 927 | 925 | 0 | 99.9903% | 99.5808% |

采用原始截线每 0.1 mm 采样，按 G-code 声明线宽估计挤出覆盖，额外允许 0.03 mm 偏差。此结果只描述指令刀路近似，不证明实际挤出、层间粘结、强度或飞行安全。没有整层漏切，不代表每个短线都被打印。

两个最差截面未覆盖的 8 个 / 22 个样点均仍在 STL 实体内；这些被复核的位置属于切片填充间隙，不能推广为所有局部遗漏原因。整体累计未覆盖截线约 31.64 / 46.21 mm（总截线长度约 380,647 / 475,888 mm）；位置、层号与图保存在本地验证证据。

两次均生成含结束标记的完整 G-code；Bambu 随后保存工程 3MF 返回 -13（Windows 无符号值 4294967283）。**G-code 生成通过；工程 3MF 保存未通过。**

## 软件检查

源码 96 项测试通过。最终 EXE 实测原始 Fuselage 3-p3：连续重建一次、导出两次、复用缓存、已有导出保留，目录仅生成两份 STL，没有自动 JSON 或 TXT。EXE 导出的 STL 与上述切片文件 SHA-256 一致。中英说明卡与界面已检查：连续模式不显示重建层高，提示层高与首层由切片器设置。未运行 GitHub CI。

## 保留限制

本次只验证这一原始模型、指定厚度与精度和两组 P1S 工艺，不覆盖所有机型、模型、材料、旋转方向或缩放比例。原始曲面直接加厚仍会影响小孔、间隙和接口。输出含内部小边界以及约 0.00000975 mm³ 的极小孤立四面体；本次未为了外观删改这些生成几何。后续精简应另有几何与刀路证据。MeshLib 再分发授权仍未解决，软件包按本地测试版交付。

## English

The original Fuselage 3-p3 was rebuilt directly as a continuous 0.45 mm thin wall at 0.10 mm geometric resolution. The same STL generated complete Bambu Regular G-code at 0.20/0.24 and 0.16/0.20 mm layer/first-layer heights, without wholly missing source layers. Commanded-bead sampling covered 99.9917% and 99.9903% of original section curves. Local fill gaps remain; tested gap points in the two worst sections were inside the solid. Project 3MF export returned -13 after full G-code generation. 96 source tests and the final EXE import/convert/cache/export workflow passed. Original source unchanged. Default stays layered; continuous mode remains optional. No physical print or universal compatibility is certified.
