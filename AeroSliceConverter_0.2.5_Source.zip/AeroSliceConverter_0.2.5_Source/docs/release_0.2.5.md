# AeroSlice Converter 0.2.5 — continuous reconstruction validation

Version remains **0.2.5**, replacing the earlier local 0.2.5 build. The default remains layered reconstruction. This build adds clearer optional continuous thin-wall operation and validation; it does not turn every model into a proven printable part.

## Changes

- Continuous mode uses the original Surface geometry, not G-code reversal or smoothing a stack of layers. The layer-height field is hidden; layer height and first-layer height are chosen in the slicer. The completed-result card and export banner state this distinction. Layered mode still requires matched heights.
- A source-coverage false positive was reproduced on Fuselage 3-p3: one of 118,049 source vertices/face centres was classified outside by a nearest-surface pseudonormal. On a closed, outward-oriented output only, disputed points are rechecked by winding number (beta 8, strict 0.95–1.05 interval) **and** an independent ray-parity test. Both must confirm containment before correcting a sign. A real uncovered source point still fails the original tolerance check; open meshes cannot use the correction.
- Already-layered 3MF input is rejected for continuous reconstruction too. STL cannot carry this metadata, so original-vs-converted input must still be tracked by the user.
- Existing import filtering, per-file failure recovery, conversion-cache reuse and direct model-only export remain. No automatic JSON or TXT sidecars are added.

## Executed checks

Full source suite: **96 passed**. Actual Fuselage 3-p3 continuous rebuild at 0.45 mm thickness / 0.10 mm geometric resolution produced **1,039,870 faces**. All 118,049 source-point coverage checks passed after one independently confirmed sign correction. 342 remote void probes found no unexpected filled cavity. Maximum output-to-source distance among 20,000 sampled output vertices was **0.2843 mm**, including the intended approximately 0.225 mm half-thickness expansion; this is not a global Hausdorff bound. Original STL unchanged.

Actual multi-height slicing and frozen-EXE checks are appended after completion. Bambu can produce full G-code while returning -13 during project-3MF export; those statuses are recorded separately. Physical printing is not verified. Redistribution authorization for MeshLib remains unresolved; see THIRD_PARTY_NOTICES.md.

## 中文

仍为 **0.2.5**，用于替换此前本地 0.2.5。默认保持逐层方式；连续薄壁为可选项，需重新导入原始 Surface 模型。连续方式不绑定打印层高，首层高度与层高均由切片器选择；逐层方式仍有层高约束。

修复 Fuselage 3-p3 的一个局部内外判定误报：只对闭合、正向实体中有争议的源点，要求严格绕数和独立射线检测同时确认在内部，才修正符号。不放宽覆盖容差，不接受真正遗漏的源点，开放网格不适用该修正。

源码 96 项测试通过；真实模型连续重建约 104 万面，118,049 个源点覆盖通过，342 个空腔探针未见意外填实。2 万个输出采样点到原面的最大距离约 0.2843 mm，包含双侧加厚造成的约 0.225 mm 外扩，不能据此保证所有尺寸配合不变。不同层高实际切片、最终 EXE 的结果在完成后补充。本次未验证实物打印，也未解决第三方运行库再分发授权。

## Final actual slicing and EXE results / 最终结果

The same STL generated full G-code at layer/first-layer heights 0.20/0.24 and 0.16/0.20 mm. No entire source layer missing; sampled commanded-bead coverage 99.9917% / 99.9903%. Local fill gaps remain. Bambu project 3MF export returned -13 after G-code generation. Final EXE: one continuous reconstruction, two cached saves, source unchanged, only STL outputs; exported STL matches the sliced file. See [detailed validation](continuous_validation_0.2.5.md).

同一 STL 两组不同层高/首层生成完整 G-code，无整层缺失；局部填充间隙仍保留，工程 3MF 保存仍失败。最终 EXE 一次连续重建、两次复用导出通过；详见[验证报告](continuous_validation_0.2.5.md)。
