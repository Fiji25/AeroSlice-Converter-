# 使用说明 / User guide

当前操作流程以 [README](../README.md) 为准。默认逐层方案，转换后查看本次成品设置卡，确保层高与首层高度一致。旧版报告中的 1 墙、三机型 3MF 预设或自动 JSON 交付说明不适用于当前桌面流程。

See the current [README](../README.md) for the workflow and limitations. Match both layer height and first-layer height to the completed result.
