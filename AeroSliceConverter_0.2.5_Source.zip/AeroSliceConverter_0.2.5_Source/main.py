"""PyInstaller entry point and source checkout launcher."""
import sys
from pathlib import Path

if not getattr(sys, "frozen", False):
    sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    from aeroslice.cli import main
    raise SystemExit(main())
