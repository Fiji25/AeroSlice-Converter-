@echo off
cd /d "%~dp0"
if exist dist_verified\AeroSliceConverter_0.2.5\AeroSliceConverter.exe (
  start "" dist_verified\AeroSliceConverter_0.2.5\AeroSliceConverter.exe
) else (
  .venv\Scripts\python.exe main.py
)
