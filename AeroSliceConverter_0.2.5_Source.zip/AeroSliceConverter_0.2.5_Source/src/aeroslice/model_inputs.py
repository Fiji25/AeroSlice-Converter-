"""Shared, deterministic model discovery for the desktop app and CLI."""
import os
from pathlib import Path


def discover_models(inputs):
    files, skipped, seen = [], [], set()
    for value in inputs:
        root = Path(value)
        candidates = sorted(root.rglob('*'), key=lambda p: str(p).casefold()) if root.is_dir() else [root]
        for path in candidates:
            if path.is_dir() or path.suffix.lower() not in ('.stl', '.3mf'):
                continue
            if path.name.startswith('._') or '__MACOSX' in path.parts:
                skipped.append(str(path))
                continue
            resolved = str(path.resolve())
            key = os.path.normcase(resolved)
            if key not in seen:
                seen.add(key)
                files.append(resolved)
    return files, skipped
