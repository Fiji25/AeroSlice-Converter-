"""Human-readable settings derived from a completed conversion snapshot."""
import math
from pathlib import Path


def settings_for_result(result):
    if result is None or result.report.get('status') != 'geometry_passed':
        raise ValueError('请先完成转换，再查看该成品的切片说明。')
    if result.report.get('method') != 'layered_sections':
        width=float(result.report.get('thickness_mm',result.report.get('options',{}).get('thickness',0)))
        if not math.isfinite(width) or not .01<=width<=10:
            raise ValueError('成品缺少有效材料宽度，请重新转换原始模型。')
        return dict(layer_height=None,first_layer_height=None,line_width=width,
                    slicing_mode=result.report.get('mode','regular'),layer_bound=False)
    requirements = result.model.metadata.get('layered_requirements', {})
    options = result.report.get('options', {})
    h = float(requirements.get('layer_height_mm', result.report.get('layer_height_mm', options.get('layer_height', 0))))
    width = float(requirements.get('line_width_mm', result.report.get('thickness_mm', options.get('thickness', 0))))
    if not math.isfinite(h) or not .05 <= h <= .4 or not math.isfinite(width) or not .01 <= width <= 10:
        raise ValueError('成品缺少有效的重建层高或材料宽度，请重新转换原始模型。')
    return dict(layer_height=h, first_layer_height=h, line_width=width,slicing_mode='even-odd',layer_bound=True)


def settings_text(result):
    s = settings_for_result(result)
    h, width = s['layer_height'], s['line_width']
    if not s['layer_bound']:
        mode='Regular (normal solid slicing)' if s['slicing_mode']=='regular' else 'Even-Odd'
        return f'''AeroSlice Converter — slicing notes for this completed solid model
Slicing mode: {mode}
Layer height and first layer height: choose in your slicer for your printer and filament.
This reconstruction does not bind geometry to a printing layer height.
Material thickness: {width:g} mm. This is a geometric thickness, not a mandatory extrusion width.
Arachne is a starting point for thin walls; inspect the actual skin and rib toolpaths.
Continuous thin-wall reconstruction thickens both sides and may shift the exterior by about half the material thickness.
Small gaps and details are limited by thickness and reconstruction accuracy. Geometry checks do not certify printing.

本次实体成品的切片说明
切片模式：{mode}
层高、首层高度：在切片软件中按打印机和耗材选择；本次重建不绑定打印层高。
材料厚度：{width:g} mm。这是几何厚度，不是强制打印线宽。
薄壁可从 Arachne 开始尝试，必须检查外皮与筋板的实际刀路。
连续薄壁沿源曲面双侧加厚，外轮廓可能增加约半个材料厚度。
小孔、间隙和细节受壁厚与重建精度影响；几何校验不等于打印验证。
'''
    return f'''AeroSlice Converter — settings for this completed layered model
Layer height: {h:g} mm
First layer height: {h:g} mm
Material / reference line width: {width:g} mm
Slicing mode: Even-Odd
Reference starting settings: Arachne; 3 wall loops; 100% material infill; 0 top / bottom layers.
Keep the original Z direction, scale and position. Disable adaptive layers.
Do not automatically repair or union the entire stack. To change layer height, rebuild the original model.
100% infill fills the reconstructed material regions, not the aircraft cavities.
Inspect the actual sliced toolpaths, skin and ribs before printing. Geometry checks do not certify printing.
These values belong to the completed result, even if the conversion controls have since changed.

本次逐层成品的切片设置
层高：{h:g} mm；首层高度：{h:g} mm
重建材料宽度 / 参考线宽：{width:g} mm
切片模式：Even-Odd（奇偶）
参考起点：Arachne 墙生成器；3 层墙；材料区域 100% 填充；顶层 / 底层均为 0。
保持原始 Z 方向、比例及位置，关闭自适应层高。
不要自动修复或布尔合并整栈。更换层高时，应从原始模型重新转换。
100% 填充针对重建的材料区域，不是填满飞机空腔。
打印前逐层检查实际刀路、外皮与筋板；几何校验通过不代表打印已验证。
这些数值来自已完成的转换结果，不随右侧控件修改而变化。
'''


def write_settings(result, path):
    path = Path(path)
    if path.suffix.lower() != '.txt':
        raise ValueError('切片设置卡只能保存为 .txt 文件。')
    content = settings_text(result)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(content)
    return path
