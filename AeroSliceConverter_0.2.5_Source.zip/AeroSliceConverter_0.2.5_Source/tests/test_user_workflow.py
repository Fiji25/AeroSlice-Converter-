from pathlib import Path
import pytest
from PySide6 import QtCore as C, QtWidgets as W
from aeroslice.core import Model, Part, sha256
from aeroslice.converters import Conversion
from aeroslice.fixtures import sheet
from aeroslice.gui import Window
from aeroslice.model_inputs import discover_models
from aeroslice.slicing_settings import settings_text, write_settings


def completed():
    model=Model([Part('sheet',sheet())],metadata={'layered_requirements':{'layer_height_mm':.2,'line_width_mm':.45}})
    return Conversion(model,{'status':'geometry_passed','method':'layered_sections'})


def test_discovery_filters_resource_forks_and_duplicates_without_changing_sources(tmp_path):
    nested=tmp_path/'wing';nested.mkdir()
    source=nested/'Wing.STL';source.write_bytes(b'original')
    project=nested/'Tail.3MF';project.write_bytes(b'original project')
    (nested/'._Wing.stl').write_bytes(b'not a mesh')
    (tmp_path/'__MACOSX').mkdir();(tmp_path/'__MACOSX'/'other.stl').write_bytes(b'fork')
    digest=sha256(source)
    found,skipped=discover_models([tmp_path,source])
    assert set(found)=={str(source.resolve()),str(project.resolve())}
    assert len(skipped)==2 and sha256(source)==digest
    missing=tmp_path/'missing.stl'
    assert discover_models([missing])[0]==[str(missing.resolve())]


def test_settings_snapshot_and_explicit_safe_txt_export(tmp_path):
    result=completed()
    text=settings_text(result)
    assert 'Layer height: 0.2 mm' in text and 'First layer height: 0.2 mm' in text
    assert '3 wall loops' in text and 'Even-Odd' in text
    assert not list(tmp_path.iterdir())
    destination=tmp_path/'settings.txt';write_settings(result,destination)
    with pytest.raises(FileExistsError):write_settings(result,destination)
    source=tmp_path/'original.stl';source.write_bytes(b'original')
    with pytest.raises(ValueError):write_settings(result,source)
    assert source.read_bytes()==b'original' and not list(tmp_path.glob('*.json'))
    with pytest.raises(ValueError):settings_text(None)


def test_continuous_settings_leave_print_layer_heights_to_slicer():
    result=Conversion(Model([Part('sheet',sheet())]),dict(status='geometry_passed',
        method='unsigned_distance_thinwall',mode='regular',thickness_mm=.45,options={'layer_height':.2}))
    text=settings_text(result)
    assert 'choose in your slicer' in text and '不绑定打印层高' in text
    assert 'First layer height: 0.2' not in text and 'Even-Odd' not in text


def test_continuous_ui_hides_reconstruction_layer_height_and_rejects_layered_input(app):
    from aeroslice.ready import convert_ready
    from aeroslice.core import Options,GeometryError
    window=Window()
    try:
        window.reconstruction.setCurrentIndex(1)
        assert window.layer_height.isHidden() and window.layer_height_label.isHidden()
        assert window.mode.currentIndex()==0
        assert '切片器设置' in window.method_note.text()
        model=completed().model
        with pytest.raises(GeometryError,match='原始Surface'):convert_ready(model,Options())
    finally:window.close()


@pytest.fixture(scope='module')
def app():
    C.QCoreApplication.setAttribute(C.Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    return W.QApplication.instance() or W.QApplication([])


def test_gui_settings_uses_completed_result_after_controls_change(app,monkeypatch):
    window=Window()
    copied=[]
    class Clipboard:
        def setText(self,value):copied.append(value)
    monkeypatch.setattr(W.QApplication,'clipboard',lambda:Clipboard())
    try:
        window.result=completed();window.layer_height.setValue(.25)
        dialog=window.show_slicing_settings()
        editor=dialog.findChild(W.QPlainTextEdit)
        assert 'Layer height: 0.2 mm' in editor.toPlainText()
        next(b for b in dialog.findChildren(W.QPushButton) if b.text()=='复制 / Copy').click()
        assert 'First layer height: 0.2 mm' in copied[-1]
        window.export_done(['result.stl'])
        assert '0.2 mm' in window.feedback.text()
        dialog.close()
    finally:window.close()


def test_gui_rejects_rebuilding_completed_3mf(app):
    window=Window()
    try:
        model=completed().model;window.models.append(model)
        window.add_model(model,{'parts':[{'reason':'test','self_intersections':{'pairs':[]}}]})
        with pytest.raises(ValueError,match='已经是逐层成品'):window.selected_model()
    finally:window.close()


def test_import_error_continues_remaining_queue_and_preserves_summary(app,monkeypatch,tmp_path):
    window=Window()
    monkeypatch.setattr(window,'refresh_views',lambda:None)
    monkeypatch.setattr(window,'fit_views',lambda:None)
    monkeypatch.setattr(window,'diagnostic_report',lambda report:None)
    jobs=[]
    def start(name,args):
        window.job_name=name;window._loading_path=args['path'];jobs.append(args['path'])
    monkeypatch.setattr(window,'start_job',start)
    try:
        bad=tmp_path/'bad.stl';good=tmp_path/'good.stl'
        window.import_paths([bad,good])
        window.on_error('GeometryError: corrupt model\ntraceback')
        assert jobs==[str(bad.resolve()),str(good.resolve())]
        model=Model([Part('good',sheet())],source=str(good))
        window.on_done((model,{'parts':[{'reason':'test','self_intersections':{'pairs':[]}}]}))
        assert len(window.models)==1
        assert '成功 1，失败 1' in window.feedback.text()
        assert 'bad.stl' in window.report_box.toPlainText()
        window.import_paths([good]);assert len(jobs)==2
    finally:window.close()
